const botonSi = document.getElementById('si');
const botonNo = document.getElementById('no');
const pantallaCorazon = document.getElementById('pantalla-corazon');
let escala = 1;

botonNo.addEventListener('click', () => {
    escala -= 0.1;
    botonNo.style.transform = `scale(${escala})`;
    botonSi.style.transform = 'scale(1.1)';
    setTimeout(() => {
        botonSi.style.transform = 'scale(1)';
    }, 300);
});

botonSi.addEventListener('click', () => {
    pantallaCorazon.classList.remove('oculto');
    setTimeout(() => {
        pantallaCorazon.classList.add('oculto');
    }, 2000);
});